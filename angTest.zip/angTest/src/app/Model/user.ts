export class User {
    id:number ;
    username:string;
    age:number;
    dob:string;
    height:number;
    weight:number;
    phone:number;
    email:string;
    address:string;
}
