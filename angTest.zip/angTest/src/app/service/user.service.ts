import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { observable, Observable } from 'rxjs';
import { User } from '../Model/user';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  public data;
  constructor(private http:HttpClient) { }
  public getdata(){
    return this.http.get('http://localhost:3000/patients');
  }
 public getbyid(id){
   return this.http.get('http://localhost:3000/patients/'+id);
 }
}
