import { Component, OnInit,ViewChild } from '@angular/core';
import { UserService } from '../service/user.service';
import {MatPaginator, MatTableDataSource} from '@angular/material';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  
  public displayedColumns : string[];
  public dataSource ;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  constructor(private service:UserService,public router:Router) { }
 

  ngOnInit() {
    this.dataSource=this.service.getdata();
    this.dataSource.paginator = this.paginator;
    this.displayedColumns = ['id', 'username', 'age', 'dob','height','weight','phone','email','address','edit','delete'];
  

  }
  edit(id){
    this.router.navigate(['/edit/'+id]);
  }

}
