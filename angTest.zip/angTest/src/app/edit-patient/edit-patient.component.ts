import { Component, OnInit } from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import { UserService } from '../service/user.service';
import { User }  from '../Model/user';

@Component({
  selector: 'app-edit-patient',
  templateUrl: './edit-patient.component.html',
  styleUrls: ['./edit-patient.component.css']
})
export class EditPatientComponent implements OnInit {
  public id;
  public data:User;
  constructor(public router:ActivatedRoute,public service:UserService) { }
  

  ngOnInit() {
    this.router.params.subscribe(data=>{
      this.id=data['id']
    })
    this.service.getbyid(this.id).subscribe(result=>{
      this.data=result as User;
    })
  }

}
